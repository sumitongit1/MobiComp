
<?php 
$conn = mysqli_connect("localhost","id12395231_sumit97","sumit1197","id12395231_sumit97");
 
if(!$conn){
	die("Connection error: " . mysqli_connect_error());	
}
?>